# Helyxium - Universal VR Bridge Platform
__version__ = "0.1.0"
__author__ = "Helyxium Team"
__description__ = "Where the World Comes Together"