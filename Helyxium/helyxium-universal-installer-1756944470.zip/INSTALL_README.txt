# Helyxium Universal Installer

## Quick Installation

### Windows
1. Extract this ZIP file
2. Open Command Prompt in the extracted folder
3. Run: `python installer\install.py`

### macOS/Linux  
1. Extract this ZIP file
2. Open Terminal in the extracted folder
3. Run: `python3 installer/install.py`

## What This Does

The installer will automatically:
- Detect your platform (Windows/macOS/Linux)
- Check Python compatibility (3.9-3.13)
- Create a virtual environment
- Install all dependencies
- Set up desktop shortcuts
- Create launcher scripts

## Requirements

- Python 3.9 or higher
- Internet connection (for dependencies)
- ~500MB free disk space

## Need Help?

See INSTALLER_GUIDE.md for detailed instructions and troubleshooting.

---
Helyxium - Universal VR Bridge Platform
